import { useEffect, useState } from "react";
import { BookOpen, Calculator, FlaskConical, Laptop, GraduationCap, Languages, LogIn, LogOut, Menu, X, UserRound, ShieldCheck, PlusCircle } from "lucide-react";
import { api } from "./api";

type Role = "STUDENT" | "TEACHER" | "ADMIN";
type User = { id: string; name: string; email: string; role: Role };
type Subject = { id: string; code: string; nameFr: string; nameMg: string; _count?: { lessons: number } };
type Lesson = { id: string; title: string; description: string; content: string; language: string; subject: { nameFr: string; nameMg: string }; author: { name: string } };

const translations = {
  fr: { home:"Accueil", subjects:"Matières", lessons:"Cours", login:"Connexion", register:"Créer un compte", logout:"Déconnexion", welcome:"Apprendre aujourd'hui, réussir demain.", intro:"Une plateforme pour progresser en Mathématiques, Physique-Chimie et Informatique.", start:"Commencer à apprendre", catalog:"Nos matières", student:"Élève", teacher:"Enseignant", admin:"Administrateur", dashboard:"Tableau de bord", noLessons:"Aucun cours publié pour le moment.", email:"Adresse e-mail", password:"Mot de passe", name:"Nom complet", submit:"Continuer", createLesson:"Créer un cours", title:"Titre du cours", description:"Description", content:"Contenu du cours", selectSubject:"Choisir une matière", publish:"Publier", language:"Langue", french:"Français", malagasy:"Malagasy", account:"Espace personnel", lessonsCount:"cours publiés" },
  mg: { home:"Fandraisana", subjects:"Taranja", lessons:"Lesona", login:"Hiditra", register:"Hamorona kaonty", logout:"Hivoaka", welcome:"Mianara anio, tafita rahampitso.", intro:"Sehatra hianarana Matematika, Fizika-Simia ary Informatika.", start:"Hanomboka hianatra", catalog:"Ireo taranja", student:"Mpianatra", teacher:"Mpampianatra", admin:"Mpitantana", dashboard:"Tabilao fitantanana", noLessons:"Mbola tsy misy lesona navoaka.", email:"Adiresy mailaka", password:"Teny miafina", name:"Anarana feno", submit:"Hanohy", createLesson:"Hamorona lesona", title:"Lohatenin'ny lesona", description:"Fanazavana", content:"Votoatin'ny lesona", selectSubject:"Hisafidy taranja", publish:"Hamoaka", language:"Fiteny", french:"Français", malagasy:"Malagasy", account:"Kaonty manokana", lessonsCount:"lesona navoaka" }
};
const icons = [Calculator, FlaskConical, Laptop];

export default function App() {
  const [lang,setLang] = useState<"fr"|"mg">("fr");
  const t = translations[lang];
  const [user,setUser] = useState<User|null>(null);
  const [subjects,setSubjects] = useState<Subject[]>([]);
  const [lessons,setLessons] = useState<Lesson[]>([]);
  const [page,setPage] = useState<"home"|"auth"|"dashboard"|"subject">("home");
  const [authMode,setAuthMode] = useState<"login"|"register">("login");
  const [selected,setSelected] = useState<string|null>(null);
  const [mobileOpen,setMobileOpen] = useState(false);
  const [error,setError] = useState("");
  const [notice,setNotice] = useState("");
  const [form,setForm] = useState({name:"",email:"",password:""});
  const [lessonForm,setLessonForm] = useState({title:"",description:"",content:"",subjectId:"",language:"fr"});
  const [showLessonForm,setShowLessonForm] = useState(false);

  async function loadData() {
    try {
      const [s,l] = await Promise.all([
        api<{subjects:Subject[]}>("/subjects"),
        api<{lessons:Lesson[]}>("/lessons")
      ]);
      setSubjects(s.subjects); setLessons(l.lessons);
    } catch { /* L'API peut être indisponible pendant le premier lancement. */ }
  }
  useEffect(() => {
    void loadData();
    const token = localStorage.getItem("edu_token");
    if (token) api<{user:User}>("/auth/me").then(r=>setUser(r.user)).catch(()=>localStorage.removeItem("edu_token"));
  }, []);

  async function submitAuth(e:React.FormEvent) {
    e.preventDefault(); setError("");
    try {
      const path = authMode === "register" ? "/auth/register" : "/auth/login";
      const result = await api<{token:string;user:User}>(path,{method:"POST",body:JSON.stringify(form)});
      localStorage.setItem("edu_token",result.token); setUser(result.user); setPage("dashboard"); setNotice("");
    } catch(err) { setError(err instanceof Error ? err.message : "Erreur."); }
  }
  function logout() { localStorage.removeItem("edu_token"); setUser(null); setPage("home"); }
  async function createLesson(e:React.FormEvent) {
    e.preventDefault(); setError(""); setNotice("");
    try {
      await api("/lessons",{method:"POST",body:JSON.stringify({...lessonForm,published:true})});
      setNotice("Cours publié avec succès."); setShowLessonForm(false);
      setLessonForm({title:"",description:"",content:"",subjectId:"",language:lang});
      await loadData();
    } catch(err) { setError(err instanceof Error ? err.message : "Erreur."); }
  }
  const roleLabel = user ? user.role==="ADMIN" ? t.admin : user.role==="TEACHER" ? t.teacher : t.student : "";
  const visibleLessons = selected ? lessons.filter(l=>subjects.find(s=>s.id===selected)?.nameFr===l.subject.nameFr) : lessons;

  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={()=>setPage("home")}><span className="brand-mark"><GraduationCap size={23}/></span><span>EDU <b>MASTER</b></span></button>
      <nav className={mobileOpen?"nav-links open":"nav-links"}>
        <button onClick={()=>{setPage("home");setMobileOpen(false)}}>{t.home}</button>
        <button onClick={()=>{setPage("subject");setSelected(null);setMobileOpen(false)}}>{t.subjects}</button>
        <button onClick={()=>{setPage("subject");setSelected(null);setMobileOpen(false)}}>{t.lessons}</button>
        {user && <button onClick={()=>{setPage("dashboard");setMobileOpen(false)}}>{t.dashboard}</button>}
      </nav>
      <div className="top-actions">
        <button className="lang-button" onClick={()=>setLang(lang==="fr"?"mg":"fr")}><Languages size={17}/>{lang==="fr"?"FR":"MG"}</button>
        {user ? <button className="outline-button" onClick={logout}><LogOut size={16}/>{t.logout}</button> : <button className="primary-button small" onClick={()=>{setAuthMode("login");setPage("auth")}}><LogIn size={16}/>{t.login}</button>}
        <button className="mobile-menu" onClick={()=>setMobileOpen(!mobileOpen)}>{mobileOpen?<X/>:<Menu/>}</button>
      </div>
    </header>

    {page==="home" && <main>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><span className="dot"/> PLATEFORME ÉDUCATIVE • COLLÈGE</span>
          <h1>{t.welcome}</h1>
          <p>{t.intro}</p>
          <div className="hero-buttons"><button className="primary-button" onClick={()=>setPage("subject")}>{t.start}<span>→</span></button><button className="text-button" onClick={()=>{setAuthMode("register");setPage("auth")}}>{t.register}</button></div>
          <div className="hero-stats"><div><b>03</b><span>{t.subjects}</span></div><div><b>2</b><span>Langues</span></div><div><b>100%</b><span>Collège</span></div></div>
        </div>
        <div className="hero-art"><div className="art-glow"/><div className="book-card"><div className="book-icon"><BookOpen size={34}/></div><span>LEARNING SPACE</span><strong>Explore. Learn.<br/>Achieve.</strong><div className="book-lines"><i/><i/><i/></div></div><div className="float-card float-one"><Calculator/><span>Mathématiques</span></div><div className="float-card float-two"><FlaskConical/><span>Physique-Chimie</span></div><div className="float-card float-three"><Laptop/><span>Informatique</span></div></div>
      </section>
      <section className="section"><div className="section-heading"><div><span className="eyebrow">APPRENDRE AUTREMENT</span><h2>{t.catalog}</h2></div><button className="text-button" onClick={()=>setPage("subject")}>Voir tout →</button></div><SubjectGrid subjects={subjects} lang={lang} onSelect={id=>{setSelected(id);setPage("subject")}}/></section>
      <section className="join-banner"><div><span className="eyebrow">EDU MASTER</span><h2>Ton parcours commence ici.</h2><p>Accède aux ressources et avance à ton rythme.</p></div><button className="primary-button" onClick={()=>{setAuthMode("register");setPage("auth")}}>{t.register} <span>→</span></button></section>
    </main>}

    {page==="auth" && <main className="auth-wrap"><div className="auth-card"><div className="auth-symbol"><GraduationCap size={30}/></div><span className="eyebrow">EDU MASTER</span><h1>{authMode==="login"?t.login:t.register}</h1><p className="muted">{authMode==="login"?"Accède à ton espace d’apprentissage.":"Crée ton compte élève gratuitement."}</p>
      <form onSubmit={submitAuth} className="form-stack">
        {authMode==="register" && <label>{t.name}<input required minLength={2} maxLength={80} value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Nom et prénom"/></label>}
        <label>{t.email}<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="exemple@email.com"/></label>
        <label>{t.password}<input required type="password" minLength={authMode==="register"?10:1} value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder={authMode==="register"?"10 caractères minimum":"Mot de passe"}/></label>
        {error && <div className="error">{error}</div>}
        <button className="primary-button full" type="submit">{t.submit} <span>→</span></button>
      </form>
      <p className="switch-auth">{authMode==="login"?"Pas encore de compte ?":"Déjà inscrit ?"} <button onClick={()=>{setAuthMode(authMode==="login"?"register":"login");setError("")}}>{authMode==="login"?t.register:t.login}</button></p>
    </div></main>}

    {page==="subject" && <main className="content-page"><div className="page-heading"><span className="eyebrow">ESPACE APPRENTISSAGE</span><h1>{t.catalog}</h1><p className="muted">Choisis une matière pour découvrir les cours disponibles.</p></div><SubjectGrid subjects={subjects} lang={lang} onSelect={id=>setSelected(selected===id?null:id)}/>{selected && <div className="lesson-section"><h2>{subjects.find(s=>s.id===selected)?.[lang==="fr"?"nameFr":"nameMg"]}</h2><LessonList lessons={visibleLessons} lang={lang}/></div>}{!selected && <div className="lesson-section"><h2>{t.lessons}</h2><LessonList lessons={lessons} lang={lang}/></div>}</main>}

    {page==="dashboard" && <main className="content-page"><div className="dashboard-heading"><div><span className="eyebrow">{t.account}</span><h1>{t.dashboard}</h1><p className="muted">Bonjour, {user?.name}.</p></div><span className="role-pill"><UserRound size={15}/>{roleLabel}</span></div>
      <div className="dashboard-grid"><div className="metric-card"><BookOpen/><b>{lessons.length}</b><span>{t.lessonsCount}</span></div><div className="metric-card"><GraduationCap/><b>3</b><span>{t.subjects}</span></div><div className="metric-card"><ShieldCheck/><b>{roleLabel}</b><span>Votre rôle</span></div></div>
      {(user?.role==="TEACHER"||user?.role==="ADMIN") && <div className="lesson-section"><div className="section-heading"><h2>{t.createLesson}</h2><button className="primary-button small" onClick={()=>setShowLessonForm(!showLessonForm)}><PlusCircle size={16}/> Nouveau cours</button></div>{showLessonForm && <form className="lesson-form form-stack" onSubmit={createLesson}><label>{t.title}<input required minLength={3} value={lessonForm.title} onChange={e=>setLessonForm({...lessonForm,title:e.target.value})}/></label><label>{t.description}<input required minLength={5} value={lessonForm.description} onChange={e=>setLessonForm({...lessonForm,description:e.target.value})}/></label><label>{t.selectSubject}<select required value={lessonForm.subjectId} onChange={e=>setLessonForm({...lessonForm,subjectId:e.target.value})}><option value="">—</option>{subjects.map(s=><option key={s.id} value={s.id}>{s.nameFr}</option>)}</select></label><label>{t.language}<select value={lessonForm.language} onChange={e=>setLessonForm({...lessonForm,language:e.target.value})}><option value="fr">Français</option><option value="mg">Malagasy</option></select></label><label>{t.content}<textarea required minLength={10} rows={7} value={lessonForm.content} onChange={e=>setLessonForm({...lessonForm,content:e.target.value})}/></label><button className="primary-button" type="submit">{t.publish}</button></form>}</div>}
      {notice && <p className="success">{notice}</p>}{error && <p className="error">{error}</p>}
      <div className="lesson-section"><h2>{t.lessons}</h2><LessonList lessons={lessons} lang={lang}/></div>
    </main>}
    <footer><div className="footer-brand"><GraduationCap/> EDU MASTER</div><span>© 2026 EDU MASTER · Apprendre, comprendre, réussir.</span><span>Français · Malagasy</span></footer>
  </div>;
}

function SubjectGrid({subjects,lang,onSelect}:{subjects:Subject[];lang:"fr"|"mg";onSelect:(id:string)=>void}) {
  const desc = lang==="fr" ? ["Développe ton raisonnement et résous des problèmes.","Explore les phénomènes physiques et les transformations chimiques.","Découvre les outils numériques et la logique informatique."] : ["Ampitomboy ny fahaiza-misaina sy famahana olana.","Fantaro ny tranga ara-fizika sy ny fiovan-javatra ara-simia.","Fantaro ny fitaovana nomerika sy ny lojikan'ny informatika."];
  const names = lang==="fr" ? ["Mathématiques","Physique-Chimie","Informatique"] : ["Matematika","Fizika-Simia","Informatika"];
  return <div className="subject-grid">{subjects.map((s,i)=>{const Icon=icons[i%3];return <button className="subject-card" key={s.id} onClick={()=>onSelect(s.id)}><span className={`subject-icon color-${i}`}><Icon size={25}/></span><span className="subject-count">{s._count?.lessons ?? 0} cours</span><h3>{lang==="fr"?s.nameFr:s.nameMg}</h3><p>{desc[i]||""}</p><span className="card-link">Explorer <b>↗</b></span></button>})}{subjects.length===0 && <p className="muted">Connecte le backend et exécute le seed pour afficher les matières.</p>}</div>;
}
function LessonList({lessons,lang}:{lessons:Lesson[];lang:"fr"|"mg"}) {
  const [opened,setOpened]=useState<string|null>(null);
  if (!lessons.length) return <div className="empty-state"><BookOpen size={28}/><p>{lang==="fr"?"Aucun cours publié pour le moment.":"Mbola tsy misy lesona navoaka."}</p></div>;
  return <div className="lesson-list">{lessons.map(l=><article className="lesson-item" key={l.id}><button className="lesson-title" onClick={()=>setOpened(opened===l.id?null:l.id)}><span><b>{l.title}</b><small>{l.description}</small></span><span>{opened===l.id?"−":"+"}</span></button>{opened===l.id && <div className="lesson-content"><p>{l.content}</p><small>Par {l.author.name} · {l.language==="mg"?"Malagasy":"Français"}</small></div>}</article>)}</div>;
}
