import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

await prisma.subject.upsert({
  where: { code: "MATHEMATICS" },
  update: {},
  create: { code: "MATHEMATICS", nameFr: "Mathématiques", nameMg: "Matematika" }
});
await prisma.subject.upsert({
  where: { code: "PHYSICS_CHEMISTRY" },
  update: {},
  create: { code: "PHYSICS_CHEMISTRY", nameFr: "Physique-Chimie", nameMg: "Fizika sy Simia" }
});
await prisma.subject.upsert({
  where: { code: "COMPUTER_SCIENCE" },
  update: {},
  create: { code: "COMPUTER_SCIENCE", nameFr: "Informatique", nameMg: "Informatika" }
});
await prisma.$disconnect();
