import "dotenv/config";
import bcrypt from "bcryptjs";
import { prisma } from "../src/db.js";

const email = process.env.ADMIN_EMAIL?.toLowerCase();
const password = process.env.ADMIN_PASSWORD;
if (!email || !password || password.length < 14) {
  throw new Error("Définis ADMIN_EMAIL et un ADMIN_PASSWORD d'au moins 14 caractères.");
}
const passwordHash = await bcrypt.hash(password, 12);
const admin = await prisma.user.upsert({
  where: { email },
  update: { role: "ADMIN", passwordHash },
  create: { name: "Administrateur", email, passwordHash, role: "ADMIN" }
});
console.log(`Administrateur prêt : ${admin.email}`);
await prisma.$disconnect();
