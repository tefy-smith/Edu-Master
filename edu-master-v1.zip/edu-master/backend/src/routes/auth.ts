import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { prisma } from "../db.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();
const registerSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(254),
  password: z.string().min(10).max(72)
});
const loginSchema = z.object({
  email: z.string().trim().email(),
  password: z.string().min(1).max(72)
});

function tokenFor(user: { id: string; role: "STUDENT" | "TEACHER" | "ADMIN" }) {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("JWT_SECRET manquant");
  return jwt.sign({ id: user.id, role: user.role }, secret, { expiresIn: "8h" });
}

router.post("/register", async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Informations invalides.", errors: parsed.error.flatten() });

  const email = parsed.data.email.toLowerCase();
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return res.status(409).json({ message: "Cette adresse e-mail est déjà utilisée." });

  const passwordHash = await bcrypt.hash(parsed.data.password, 12);
  // Important : le rôle est fixé côté serveur. L'inscription publique ne peut créer qu'un élève.
  const user = await prisma.user.create({
    data: { name: parsed.data.name, email, passwordHash, role: "STUDENT" },
    select: { id: true, name: true, email: true, role: true }
  });
  return res.status(201).json({ token: tokenFor(user), user });
});

router.post("/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "E-mail ou mot de passe invalide." });

  const user = await prisma.user.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
  if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) {
    return res.status(401).json({ message: "E-mail ou mot de passe incorrect." });
  }
  const safeUser = { id: user.id, name: user.name, email: user.email, role: user.role };
  return res.json({ token: tokenFor(user), user: safeUser });
});

router.get("/me", requireAuth, async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    select: { id: true, name: true, email: true, role: true }
  });
  if (!user) return res.status(404).json({ message: "Utilisateur introuvable." });
  return res.json({ user });
});

export default router;
