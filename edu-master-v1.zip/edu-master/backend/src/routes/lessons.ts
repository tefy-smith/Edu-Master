import { Router } from "express";
import { z } from "zod";
import { prisma } from "../db.js";
import { requireAuth, requireRoles } from "../middleware/auth.js";

const router = Router();
const lessonSchema = z.object({
  title: z.string().trim().min(3).max(160),
  description: z.string().trim().min(5).max(500),
  content: z.string().min(10).max(50000),
  language: z.enum(["fr", "mg"]).default("fr"),
  subjectId: z.string().min(1),
  published: z.boolean().default(false)
});

router.get("/", async (req, res) => {
  const subjectId = typeof req.query.subjectId === "string" ? req.query.subjectId : undefined;
  const lessons = await prisma.lesson.findMany({
    where: { published: true, ...(subjectId ? { subjectId } : {}) },
    orderBy: { createdAt: "desc" },
    select: {
      id: true, title: true, description: true, content: true, language: true,
      createdAt: true, subject: { select: { id: true, nameFr: true, nameMg: true } },
      author: { select: { name: true } }
    }
  });
  res.json({ lessons });
});

router.post("/", requireAuth, requireRoles("TEACHER", "ADMIN"), async (req, res) => {
  const parsed = lessonSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Données du cours invalides.", errors: parsed.error.flatten() });
  const subject = await prisma.subject.findUnique({ where: { id: parsed.data.subjectId } });
  if (!subject) return res.status(404).json({ message: "Matière introuvable." });

  const lesson = await prisma.lesson.create({
    data: { ...parsed.data, authorId: req.user!.id }
  });
  res.status(201).json({ lesson });
});

export default router;
