import { Router } from "express";
import { prisma } from "../db.js";
const router = Router();

router.get("/", async (_req, res) => {
  const subjects = await prisma.subject.findMany({
    orderBy: { nameFr: "asc" },
    include: { _count: { select: { lessons: { where: { published: true } } } } }
  });
  res.json({ subjects });
});
export default router;
