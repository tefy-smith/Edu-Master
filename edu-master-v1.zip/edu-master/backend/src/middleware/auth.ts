import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { Role } from "@prisma/client";

export type AuthUser = { id: string; role: Role };
declare global {
  namespace Express {
    interface Request { user?: AuthUser }
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const token = header?.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: "Authentification requise." });

  try {
    const secret = process.env.JWT_SECRET;
    if (!secret) throw new Error("JWT_SECRET manquant");
    req.user = jwt.verify(token, secret) as AuthUser;
    next();
  } catch {
    return res.status(401).json({ message: "Session invalide ou expirée." });
  }
}

export function requireRoles(...roles: Role[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) return res.status(401).json({ message: "Authentification requise." });
    if (!roles.includes(req.user.role)) return res.status(403).json({ message: "Accès interdit." });
    next();
  };
}
