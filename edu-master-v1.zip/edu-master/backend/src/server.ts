import "dotenv/config";
import express from "express";
import cors from "cors";
import authRoutes from "./routes/auth.js";
import subjectRoutes from "./routes/subjects.js";
import lessonRoutes from "./routes/lessons.js";
import { prisma } from "./db.js";

const app = express();
const port = Number(process.env.PORT || 4000);
app.use(cors({ origin: process.env.FRONTEND_URL || "http://localhost:5173" }));
app.use(express.json({ limit: "100kb" }));

app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "EDU MASTER" }));
app.use("/api/auth", authRoutes);
app.use("/api/subjects", subjectRoutes);
app.use("/api/lessons", lessonRoutes);

app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(500).json({ message: "Une erreur serveur est survenue." });
});

app.listen(port, () => console.log(`EDU MASTER API : http://localhost:${port}`));
process.on("SIGINT", async () => { await prisma.$disconnect(); process.exit(0); });
