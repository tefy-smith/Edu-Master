# EDU MASTER — V1

Plateforme pédagogique Web pour le collège : Mathématiques, Physique-Chimie et Informatique.

## Stack
- Frontend : React + TypeScript + Vite
- Backend : Node.js + Express + TypeScript
- Base de données : PostgreSQL + Prisma
- Authentification : bcrypt + JWT
- Interface : Tailwind CSS

## Prérequis
- Node.js 20+
- npm
- PostgreSQL 15+

## Démarrage rapide

### 1. Base de données
Crée une base PostgreSQL nommée `edu_master`, puis configure `backend/.env` à partir de `.env.example`.

### 2. Backend
```bash
cd backend
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```
Le serveur démarre sur http://localhost:4000.

### 3. Frontend
Dans un autre terminal :
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```
Ouvre http://localhost:5173.

## Comptes et rôles
- L'inscription publique crée toujours un compte `STUDENT`.
- Les rôles `TEACHER` et `ADMIN` ne sont jamais attribuables via l'inscription publique.
- Un administrateur initial doit être créé de manière contrôlée. Pour la V1, utilise le script `backend/scripts/create-admin.ts` avec les variables `ADMIN_EMAIL` et `ADMIN_PASSWORD`, puis supprime ces variables de l'environnement.
- Ne déploie pas avec les secrets d'exemple.

## Routes API
- `POST /api/auth/register` — inscription élève
- `POST /api/auth/login` — connexion
- `GET /api/auth/me` — profil connecté
- `GET /api/subjects` — matières
- `GET /api/lessons` — cours publiés
- `POST /api/lessons` — création de cours (enseignant/admin)

## Prochaines étapes
1. Ajouter une interface de gestion des cours.
2. Ajouter exercices, QCM et corrections.
3. Ajouter gestion des utilisateurs et validation des contenus.
4. Ajouter tests, limitation de débit, validation renforcée, journalisation et déploiement HTTPS.
